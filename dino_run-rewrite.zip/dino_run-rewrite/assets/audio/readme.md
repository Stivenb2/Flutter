## None of the audio files under this directory are owned by this repo owner. Following are the links to original their origin

## BGM

- [8BitPlatformerLoop.wav](8Bit%20Platformer%20Loop.wav)
  - Author: <https://timbeek.itch.io/>
  - Link: <https://timbeek.itch.io/royalty-free-music-pack>

## SFX

- [jump14.wav](jump14.wav)
- [hurt7.wav](hurt7.wav)
  - Author: <https://mikiz.itch.io/>
  - Link: <https://mikiz.itch.io/mega-music-pack-v2-over-160-sounds>