## None of the images, sprites or textures under this directory are owned by this repo owner. Following are the links to original their origin

## Dino

- [DinoSprites - tard.png](DinoSprites%20-%20tard.png)
- [DinoSprites_tard.gif](DinoSprites_tard.gif)
  - Author: <https://arks.itch.io/>
  - Link: <https://arks.itch.io/dino-characters>

## Parallax

- [plx-1.png](parallax/plx-1.png)
- [plx-2.png](parallax/plx-2.png)
- [plx-3.png](parallax/plx-3.png)
- [plx-4.png](parallax/plx-4.png)
- [plx-5.png](parallax/plx-5.png)
- [plx-6.png](parallax/plx-6.png) edited (original name was *jungle-tileset.png*)
  - Author: <https://jesse-m.itch.io/>
  - Link: <https://jesse-m.itch.io/jungle-pack>

## Enemies

- [AngryBig/Walk (36x30).png](AngryPig/Walk%20(36x30).png)
- [Bat/Flying (46x30).png](Bat/Flying%20(46x30).png)
- [Rino/Run (52x34).png](Rino/Run%20(52x34).png)
  - Author: <https://pixelfrog-store.itch.io/>
  - Link: <https://pixelfrog-store.itch.io/pixel-adventure-2>
